get "/", forward: "/WEB-INF/pages/index.gtpl"
get "/signup", forward: "/WEB-INF/pages/signup.gtpl"
get "/upload", forward: "/WEB-INF/pages/upload.gtpl"
get "/uploadauto", forward: "/WEB-INF/pages/uploadauto.gtpl"
get "/download", forward: "/WEB-INF/pages/download.gtpl"
get "/anynines.war",  forward: "/WEB-INF/downloads/anynines.war" 
get "/anynines.zip",  forward: "/WEB-INF/downloads/anynines.zip" 
get "/facts", forward: "/WEB-INF/pages/facts.gtpl"

